package com.finan.orcamento

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class OrcamentoApplication

fun main(args: Array<String>) {
	runApplication<OrcamentoApplication>(*args)
}
